Changes for 1.8.3 since 1.8.2
-----------------------------

  - ipavault: Fix missing whitespace after keyword issue (#880)
  - ipareplica: ipareplica_setup_adtrust fails while updating ipaNTFlatName (#877)

Detailed changelog for 1.8.3 since 1.8.2 by author
--------------------------------------------------
  1 authors, 2 commits

Thomas Woerner (2)

  - ipavault: Fix missing whitespace after keyword issue
  - ipareplica: ipareplica_setup_adtrust fails while updating ipaNTFlatName

