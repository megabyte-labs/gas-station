Changes for 1.9.2 since 1.9.1
-----------------------------

  - ipabackup: Use ipabackup_item again in copy_backup_to_server (#1033)

Detailed changelog for 1.9.2 since 1.9.1 by author
--------------------------------------------------
  1 authors, 1 commits

Thomas Woerner (1)

  - ipabackup: Use ipabackup_item again in copy_backup_to_server

